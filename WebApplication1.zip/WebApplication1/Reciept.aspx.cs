﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BusinessLayer;

namespace WebApplication1
{
    public partial class Reciept : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("PresentationLayer/Login.aspx");
            }

        }
        [WebMethod]
        public static string BuyMovies(string bill)
        {
            User user = (User)HttpContext.Current.Session["User"];

            user.cart.UserID = user.ID;
            user.cart.totalbill = (float)Convert.ToSingle(bill);
            user.cart.addToCart();
            return $"{user.cart.ID}";
        }

        [WebMethod]
        public static string getUserData()
        {
            User user = (User)HttpContext.Current.Session["User"];
            return $"{user.Name}/{user.Address}/{user.Contact}";
        }
        [WebMethod]
        public static string SavePurchaseDetails(string movieID, string moviePrice )
        {
            User user = (User)HttpContext.Current.Session["User"];
            user.cart.savePurchases(movieID, moviePrice);

            return "success";
        }
    }
}