﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Hosting;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BusinessLayer;

namespace WebApplication1
{
    public partial class MovieFlix : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("PresentationLayer/Login.aspx");
            }

        }

        public string getPath(string imagename) {
            return Server.MapPath(@"Posters/" + imagename);
        }


        protected void LogOut(object sender, EventArgs e) 
        {
            Session["User"] = null;

            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));

            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            Response.Cache.SetNoStore();
            Session.Clear();
            Response.Redirect("PresentationLayer/Login.aspx");
        }


        protected void userManager(object sender, EventArgs e)
        {
            User user = (User)Session["User"];
            if (user.IsAdmin) { Response.Redirect("ManageCustomers.aspx"); }
            else
            {
                Response.Write("<script>Only admin can do that.</script>");
            }


        }
        protected void addMovie(object sender, EventArgs e)
        {
            User user = (User)Session["User"];
            if (user.IsAdmin) { Response.Redirect("PresentationLayer/AddMovie.aspx"); }
            else
            {
                Response.Write("<script>Only admin can do that.</script>");
            }

        }

        [WebMethod]
        public static string getMovies()
        {
            Moviestore movieStore = new Moviestore();
            DataTable dtable = movieStore.getAllMovies();
            return JsonConverter(dtable);
        }
        [WebMethod]
        public static string getSuggestion()
        {
            SearchEngine searchEngine = new SearchEngine();
            searchEngine.user= (User)HttpContext.Current.Session["User"];
            DataTable dtable = searchEngine.showSuggestion();
            foreach (DataRow dataRow in dtable.Rows)
            {
                foreach (var item in dataRow.ItemArray)
                {
                    Console.WriteLine(item);
                }
            }
            return JsonConverter(dtable);
        }

        public static string JsonConverter(DataTable table)
        {
            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
    }
}