﻿//function ajaxCall() {
//    $.ajax({

//        // Our sample url to make request 
//        url:
//            'ManageCustomers.aspx/getData',

//        // Type of Request
//        type: "GET",

//        // Function to call when to
//        // request is ok 
//        success: function (data) {
//            var x = JSON.stringify(data);
//            console.log(x);
//            for (var i = 0; i < data.length; i++)
//            {
//                var row = '<tr>'
//                for (var j = 0; j < data.length; j++)
//                {
//                    row += `<td>${data[i][j]}</td>`
//                    //$('#dataTable').append(`<td>${data[i]}</td><\tr>`)
//                }
//                row+='</tr>'
//                $('#dataTable').append(row)
//            }
//        },

//        // Error handling 
//        error: function (error) {
//            console.log(`Error ${error}`);
//        }
//    });
//}
//var data=[[1,2,3,4,5,6],[11,22,33,44,55,66],[12,23,34,45,56,61]]
////ajaxCall();
//for (var i = 0; i < 5; i++) {
//    var row = '<tr>'
//    for (var j = 0; j < 3; j++) {
//        row += `<td>${data[i][j]}</td>`
//        //$('#dataTable').append(`<td>${data[i]}</td><\tr>`)
//    }
//    row += '</tr>'
//    $('#dataTable').append(row)
//}
$(document).ready(function () {
    $.ajax({
        url: 'ManageCustomers.aspx/getData',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (data) {
            repFunc(data, '#dataTable')
        }
    });
})
function repFunc(data, tablename) {
    $('#dataTable').DataTable({
        data: JSON.parse(data.d),
        columns: [
            { "data": "ID" },
            { "data": "Username" },
            { "data": "Email" },
            { "data": "Address" },
            { "data": "Contact" },
            //{ "data": "Email" }
             {
                 'data': 'Rating',
                 "render": function (data, type, row, meta) {
                     var deleteButton = `<button type="button" id="${meta.row}" data-toggle="modal" data-target="#userModal" class="btn action-btn btn-success btn-sm edit-btn mr-1" onclick="deleteData(this)">Delete</button>`;
                     return deleteButton;
                 },
                 "sortable": false,
                 "searchable": false,
                 "visible": true
             }
        ],
        order: [[0, 'asc']],
    });
}
function deleteData(obj)
{
    var assent = confirm("Do you really want to delete.")
    if (assent) {
        //deleteOnServerSide($('#dataTable').DataTable().row(parseInt(obj.id)));
        $('#dataTable').DataTable().on('click', 'tbody td ', function () {
            var rowData = parseInt($('#dataTable').DataTable().cell(this).index().row);
            var userId = parseInt($('#dataTable').DataTable().cell(rowData, 0).data())
            console.log(userId, rowData)
            $('#dataTable').DataTable().row(rowData).remove().draw();
            deleteOnServerSide(userId)
        });

    }

}
function deleteOnServerSide(ID)
{
    $.ajax({
        url: 'ManageCustomers.aspx/deleteUser',
        method: 'post',
        dataType: 'json',

        contentType: 'application/json',
        data: "{id:'" + ID.toString() + "'}",
        async: false,
        success: function (data) {
            alert("Deleted successfully")
        }
    });
}