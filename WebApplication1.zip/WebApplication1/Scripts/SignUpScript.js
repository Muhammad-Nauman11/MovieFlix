﻿function register()
{
    var nameBox = document.getElementById('namebox')
    var emailBox = document.getElementById('emailbox')
    var passwordBox = document.getElementById('passwordbox')
    var repasswordBox = document.getElementById('repasswordbox')
    var addressBox = document.getElementById('addressbox')
    var contactBox = document.getElementById('contactbox')

    var namevalue, emailvalue, passwordvalue, repasswordvalue, addressvalue, contactvalue
    namevalue = nameBox.value
    emailvalue = emailBox.value

    passwordvalue = passwordBox.value
    repasswordvalue = repasswordBox.value

    addressvalue = addressBox.value
    contactvalue = contactBox.value

    if (validate(namevalue, emailvalue, passwordvalue, repasswordvalue, addressvalue, contactvalue))
    {
        registerOnServerSide(namevalue, emailvalue, passwordvalue, addressvalue, contactvalue)
    }
}

function validate(namevalue,emailvalue,passwordvalue,repasswordvalue,addressvalue,contactvalue)
{

    if (namevalue == "") {
        alert("Please enter a user name")
        return false;
    }
    else if (emailvalue == "") {
        alert("Please enter an email")
        return false;
    }
    else if (!emailvalue.includes("@") || !emailvalue.endsWith(".com")) {
        alert("Email format is invalid")
        return false;
    }
    else if (passwordvalue == "") {
        alert("Please enter a password")
        return false;
    }
    else if (repasswordvalue == "") {
        alert("Please confirm password")
        return false;

    }
    else if (addressvalue == "") {
        alert("Please provide an address")
        return false;
    }
    else if (contactvalue == "") {
        alert("Please provide a contact number")
        return false;
    }
    else if (passwordvalue != repasswordvalue) {
        alert("Passwords do not match")
        return false;
    }
    else if (!passwordValidation(passwordvalue))
    {
        alert("Password must contain a symbol, a lower and an upper case letter, a numeric and must be 8 to 15 characters long")
        return false;
    }
    return true;
}

function passwordValidation(password)
{
    // Validate lowercase letters
    var lowerCaseLetters = /[a-z]/g;
    if (!password.match(lowerCaseLetters)) {
        return false;

    }
    // Validate capital letters
    var upperCaseLetters = /[A-Z]/g;
    if (!password.match(upperCaseLetters)) {
        return false;
    }
    // Validate numbers
    var numbers = /[0-9]/g;
    if (!password.match(numbers)) {
        return false;
    }


    // Validate length

    if (password.length < 8 || password.length > 15) {
        return false;
    }
    return true;
}



function registerOnServerSide(namevalue, emailvalue, passwordvalue, addressvalue, contactvalue, isadmin=false)
{
    $.ajax({
        type: "POST",
        url: "SignUp.aspx/Register?paramater=parameter",
        data: "{ name: '" + namevalue + "',email: '" + emailvalue + "',password: '" + passwordvalue + "',address: '" + addressvalue + "',contact: '" + contactvalue + "',IsAdmin: '" + isadmin + "'}",

        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            var message
            switch (result.d)
            {
                case "nameExist":
                    message = "User name already exists"
                    break;
                case "emailExist":
                    message = "Email already exists"
                    break;
                case "success":
                    message = "User is registered successfully"
                    break;
            }
            alert(message);
            if (result.d == "success") {
                setTimeout(window.location.href = "Login.aspx", 200)
            }
        }
    });
}
function ShowPassword(id) {
    var pwdTag = document.getElementById(id)
    if (pwdTag.type == "password") {
        pwdTag.setAttribute('type', 'text');
    }
    else {
        pwdTag.setAttribute('type', 'password');
    }
}













//function validateForm() {
//    var a = document.forms["Form"]["answer_a"].value;
//    var b = document.forms["Form"]["answer_b"].value;
//    var c = document.forms["Form"]["answer_c"].value;
//    var d = document.forms["Form"]["answer_d"].value;
//    if (a == null || a == "", b == null || b == "", c == null || c == "", d == null || d == "") {
//        alert("Please Fill All Required Field");
//        return false;
//    }
//}