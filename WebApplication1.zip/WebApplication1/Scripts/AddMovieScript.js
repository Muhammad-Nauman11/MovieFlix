﻿var selectedFiles;

$(document).ready(function () {
    var box;
    box = document.getElementById("box");
    box.addEventListener("dragenter", OnDragEnter, false);
    box.addEventListener("dragover", OnDragOver, false);
    box.addEventListener("drop", OnDrop, false);

};
function OnDragEnter(e) {
    e.stopPropagation();
    e.preventDefault();
}

function OnDragOver(e) {
    e.stopPropagation();
    e.preventDefault();
}

function OnDrop(e) {
    e.stopPropagation();
    e.preventDefault();
    selectedFiles = e.dataTransfer.files;
    $("#box").text(selectedFiles.length + " file(s) selected for uploading!");
}
$("#upload").click(function () {
    var data = new FormData();
    for (var i = 0; i < selectedFiles.length; i++) {
        data.append(selectedFiles[i].name, selectedFiles[i]);
    }
    $.ajax({
        type: "POST",
        url: "AddMovie.aspx",
        contentType: false,
        processData: false,
        data: data,
        success: function (result) {
            alert(result);
        },
        error: function () {
            alert("There was error uploading files!");
        }
    });
});