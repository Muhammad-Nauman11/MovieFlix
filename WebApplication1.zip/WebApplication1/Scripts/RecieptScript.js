﻿var cart = []
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); 
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;
if (sessionStorage.getItem("cart") !== null)
{
    cart = JSON.parse(sessionStorage.getItem("cart"))
    var billbox = document.getElementById("totalInvoice")
    billbox.textContent = sessionStorage["totalbill"].toString()+"$"

}
var issuedatebox = document.getElementById("issuedate")
issuedatebox.textContent = today
getCurrentUser()
makeReciept()

function makeReciept()
{
    var classes =
        [
            ["row", "mb-2", "mb-sm-0", "py-25"],
            ["row", "mb-2","mb-sm-0", "py-25","bgc-default-l4"]
        ]

    Object.keys(cart).forEach(i => {
        var cell = document.createElement("div")
        if (i % 2 == 0) {
            for (var j = 0; j < classes[0].length; j++) {
                cell.classList.add(classes[0][j])
            }
        }
        else {
            for (var j = 0; j < classes[1].length; j++) {
                cell.classList.add(classes[1][j])
            }
        }
        var cellinside = `
                <div class="d-none d-sm-block col-1">${parseInt(i) + 1}</div>
                <div class="col-9 col-sm-5">${cart[i.toString()]["MovieName"]}</div>
                <div class="d-none d-sm-block col-2">1</div>
                <div class="d-none d-sm-block col-2 text-95">${cart[i.toString()]["Price"]}$</div>
                <div class="col-2 text-secondary-d2">${cart[i.toString()]["Price"]}$</div>
            `
        cell.innerHTML = cellinside

        var parent = document.getElementById("purchaseTable")
        parent.appendChild(cell)
    });
    
}
function purchase()
{
    if (parseFloat(sessionStorage.getItem("totalbill")) > 0) {
        $.ajax({
            type: "POST",
            url: "Reciept.aspx/BuyMovies?paramater=parameter",
            data: "{ bill: '" + sessionStorage.getItem("totalbill").toString() + "'}",

            contentType: "application/json; charset=utf-8",

            dataType: "json",

            async: "false",

            cache: "false",

            success: function (result) {
                var purchaseID = result.d
                Object.keys(cart).forEach(i => { saveDetails(cart[i.toString()]["ID"], cart[i.toString()]["Price"]) });
                alert("You have successfully purchased these movies.");
                setTimeout(window.location.href = "MovieFlix.aspx", 200)
            }
        });
    }
    else { 
        alert("You haven't bought anything")
    }
}
function saveDetails(movieID, moviePrice) {
    $.ajax({
        type: "POST",
        url: "Reciept.aspx/SavePurchaseDetails?paramater=parameter",
        data: "{ movieID: '" + movieID + "', moviePrice: '" + moviePrice + "'}",

        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            
        }
    });
}

function getCurrentUser() {
    $.ajax({
        type: "POST",
        url: "Reciept.aspx/getUserData?paramater=parameter",
       
        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            showUserDetails(result.d.split('/'))

        }
    });
}
function showUserDetails(userdata)
{
    var nametag = document.getElementById('username')
    var addresstag = document.getElementById('address')
    var contacttag = document.getElementById('contact')
    nametag.textContent = userdata[0]
    addresstag.textContent = userdata[1]
    contacttag.textContent=userdata[2]
}