﻿var data
var cart = {};
var totalBill = 0;
var numberOfCartItems = 0;
var suggestedgenres=[]
var suggestedMovies = {}
var suggestMovieIDs=[]
$(document).ready(function () {
    $.ajax({
        url: 'MovieFlix.aspx/getSuggestion',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (result) {
            suggestedgenres = JSON.parse(result.d)
            //console.log(suggestedgenres)

        }
    });
    $.ajax({
        url: 'MovieFlix.aspx/getMovies',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (result) {
            showMovies(result)
        }
    });

})
function getUnique(array) {
    var uniqueArray = [];

    // Loop through array values
    for (i = 0; i < array.length; i++) {
        if (uniqueArray.indexOf(array[i]) === -1) {
            uniqueArray.push(array[i]);
        }
    }
    return uniqueArray;
}

function showMovies(result) {
    var movieList = document.getElementById("movie-list")
    data = JSON.parse(result.d)

    for (var i = 0; i < data.length; i++) {
        var moviecontainer = document.createElement("div")


        moviecontainer.classList.add("card")

        moviecontainer.classList.add("movie")
        moviecontainer.classList.add("h-100")

        moviecontainer.id = data[i]['ID'];
        moviecontainer.style.width="20rem"
        var movie =
            `

                <img class="card-img-top" src='../Posters/${data[i]['Image_Path']}' width="250px" height="250px" alt="Card image cap" onclick="showModal(this);"/>
                    <div class="card-body">
                        <h5 class="card-title">${data[i]['MovieName']} (${data[i]['Year']})</h5>
                        <p class="card-text duration">Duration: ${data[i]['Duration']}</p>
                        <p class="card-text">IMDB: <span class="rating" style='color:gold;'>${data[i]['Rating']}</span></p>
                        <p class="card-text" style="font-weight:700;">Genre: <span class="genre" style="font-weight:200;">${data[i]['Genre']}</span></p>
                        <p class="card-text">Price: <span class="price" style='color:green;'>${data[i]['Price']}$</span></p>
                        <p class="card-text description" style="display: none;">${data[i]['Description']}
                        </p>

                        <div class="text-center card-footer border-top-0 bg-transparent"><button type="button" class="btn btn-success addbtn${i}" id="addbtn${i}" onclick="addToCart(this)">Add to cart</button></div>

                        
                    </div>
  
            `
        moviecontainer.innerHTML = movie

        movieList.appendChild(moviecontainer)
    }
    suggestMovieIDs = []
    for (var j = 0; j < suggestedgenres.length; j++) {
        var genre = suggestedgenres[j]['Genrename']

        for (var i = 0; i < data.length; i++) {
            if (data[i]['Genre'].includes(genre))
            {
                if (!suggestedMovies.hasOwnProperty(genre)) {
                    suggestedMovies[genre] = [i]
                }
                else
                {
                    suggestedMovies[genre].push(i)
                }
            }
        }

        for (var [key, value] of Object.entries(suggestedMovies)) {
            for (var ind = 0; ind < value.length; ind++) {
                var movieID = value[ind];
                //console.log("dc", movieID, "da", suggestMovieIDs)
                suggestMovieIDs.push(movieID)
            }
            
        }

    }
    //suggestMovieIDs.remove(undefined)
    var suggestMovieIDs = getUnique(suggestMovieIDs);
    
    //console.log(suggestMovieIDs)
    ////console.log("hellos", _.sampleSize(suggestMovieIDs, 4))
    makeCarousels()
    function makeCarousels() {
        if (suggestMovieIDs.length <= 0) {

            suggestMovieIDs = ['1', '2', '3', '4']
        }
        var numberOFsuggestedMovies = suggestMovieIDs.length
        if (numberOFsuggestedMovies > 4) {
            numberOFsuggestedMovies = 4
            //console.log("in", suggestMovieIDs)
        }
        suggestMovieIDs = shuffle(suggestMovieIDs)
        //console.log("out", suggestMovieIDs)
        var parent = document.getElementById("carousels")
        for (var i = 0; i < numberOFsuggestedMovies; i++) {

            var id = suggestMovieIDs[i]
            var parentIndicator = document.getElementById('indicators')
            var liIndicator = document.createElement("li")
            liIndicator.setAttribute('data-target', '"#carouselExampleIndicators')
            liIndicator.setAttribute('data-slide-to', i.toString())
            var carousel = document.createElement("div")
            carousel.classList.add("carousel-item")

            // < div class="carousel-item active" >
            if (i == 0) { carousel.classList.add("active"); liIndicator.classList.add("active"); }
            var innerChild =
                `
            <img src="Posters/${data[id]["Image_Path"]}" alt="${data[id]["MovieName"]}"class="d-block w-100 addbtn${id}" style="height:70vh;" id="movie${id}" onclick="showModal(this)"/>
            <div class="carousel-caption d-none d-md-block">
                <h5>${data[id]["MovieName"]} (${data[id]["Year"]})</h5>
                <p>Price:  <span style="color:green;">${data[id]["Price"]}</span></p>
                <p class="card-text description" style="display: none;">${data[id]['Description']}</p>
                <div class="text-center card-footer border-top-0 bg-transparent"><button type="button" class="btn btn-success addbtn${id}" id="addbtn${id}" onclick="addToCart(this)">Add to cart</button></div>
            </div>
            `
            carousel.innerHTML = innerChild
            parentIndicator.append(liIndicator)
            parent.appendChild(carousel)
        }
    }
}
function shuffle(a) {
    var x, t, r = new Uint32Array(1);
    for (var i = 0, c = a.length - 1, m = a.length; i < c; i++, m--) {
        crypto.getRandomValues(r);
        x = Math.floor(r / 65536 / 65536 * m) + i;
        t = a[i], a[i] = a[x], a[x] = t;
    }

    return a;
}

function showReciept()
{
    sessionStorage.setItem("cart", JSON.stringify(cart));
    sessionStorage.setItem("totalbill", totalBill);
    location.href="Reciept.aspx"
}
function addToCart(obj) {
    numberOfCartItems += 1
    var id = parseInt(obj.id.replace("addbtn", ""))
    var btnMovies = document.querySelectorAll('.'+obj.id);
    var parent = document.getElementById("cartItemstable")
    var child = document.createElement("tr")
    var inner =
        `
        <td colspan="3">${data[id]['MovieName']}</td>
        <td>${data[id]['Price']}$</td>
        <button class="btn btn-warning" type="button" id="${id}" onclick="removeFromCart(this)"><i class="bi bi-trash"></i> Remove</td>
        `
    child.innerHTML = inner
    parent.appendChild(child)
    btnMovies.forEach((box, index) => {
        box.setAttribute("disabled", "");
        });
    //for (var i = 0; i < btnMovies.length;i++)
    //{
    //    btnMovies[i].setAttribute("disabled", "")
    //}
    //obj.setAttribute("disabled", "")
    cart[id.toString()] = data[id]
    totalBill += parseFloat(data[id]["Price"])
    var totalPrice = document.getElementById("totalPrice")
    totalPrice.textContent = (totalBill).toString() + "$"
    var numberofitems = document.getElementById("itemsnumber")
    numberofitems.textContent = (numberOfCartItems).toString()


}
function removeFromCart(obj)
{
    numberOfCartItems -= 1;
    var id = parseInt(obj.id)
    //console.log(cart)
    totalBill -= parseFloat(data[id]["Price"])
    var totalPrice = document.getElementById("totalPrice")
    totalPrice.textContent = (totalBill).toString() + "$"
    delete cart[obj.id]
    var parent = obj.parentElement;
    parent.remove()
    var numberofitems = document.getElementById("itemsnumber")
    numberofitems.textContent = (numberOfCartItems).toString()
    //var addCartBtn = document.getElementById("addbtn" + obj.id)
    //addCartBtn.removeAttribute('disabled')
    $(".addbtn" + obj.id).prop('disabled', false);



}

const search = (check) => {
    const searchbox = document.getElementById("search-item").value.toUpperCase();
    if (searchbox.length != 0 && check == "check") { return; }
    // const storeitems=document.getElementById("product-list")
    const product = document.querySelectorAll(".movie")
    const names = document.getElementsByTagName("h5")


    var maxlength = names.length//>pname2.length?pname.length: pname2.length;
    for (var i = 0; i < maxlength; i++) {

        let matchname = product[i].getElementsByTagName("h5")[0]
        let matchdurations = product[i].getElementsByClassName("duration")[0]
        let matchratings = product[i].getElementsByClassName("rating")[0]
        let matchprices = product[i].getElementsByClassName("price")[0]
        let matchgenres = product[i].getElementsByClassName("genre")[0]
        if (matchname || matchdurations || matchratings || matchprices || matchgenres) {
            let name = matchname.textContent || matchname.innerHTML
            let duration = matchdurations.textContent || matchdurations.innerHTML
            let rating = matchratings.textContent || matchratings.innerHTML
            let price = matchprices.textContent || matchprices.innerHTML
            let genre = matchgenres.textContent || matchgenres.innerHTML
            if (name.toUpperCase().indexOf(searchbox) > -1 || duration.toUpperCase().indexOf(searchbox) > -1 || rating.toUpperCase().indexOf(searchbox) > -1 || price.toUpperCase().indexOf(searchbox) > -1 || genre.toUpperCase().indexOf(searchbox) > -1) {
                product[i].style.display = "";
            }
            else {
                product[i].style.display = "none";
            }
        }
    }

}


var modalwrap = null
var modalwrap2 = null
var recieptModalbox=null

const showModal = (obj) => {
    if (modalwrap != null) {
        modalwrap.remove()
    }
    let parent = obj.parentElement
    let matchname = parent.getElementsByTagName("h5")[0]
    let description = parent.getElementsByClassName("description")[0]
    modalwrap = document.createElement("div")
    modalwrap.innerHTML =
        `
    <div class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    ${matchname.textContent || matchname.innerHTML}
                    <button type="button"  data-dismiss="modal">&times;</button>
                </div>
                <img class="card-img-top" src='${obj.src}' width="500px" height="500px" alt="Card image cap">
                <div class="modal-body text-justify">
                    <p >
                        ${description.textContent || description.innerHTML}
                    </p>
                </div>
            </div>
        
        </div>
    </div>
    `;
    document.body.append(modalwrap)
    var modal = new bootstrap.Modal(document.querySelector(".modal"))
    modal.show()
}
var selectedgenre
var data = ["Horror", "Action", "Adventure", "Comedy"]


function uploadMovie() {

    var elem = document.getElementById("file-ip-1")
    var name = elem.files[0]["name"];
    var src = URL.createObjectURL(elem.files[0]);


    $.ajax({
        url: 'MovieFlix.aspx/uploadMovie',
        type: 'post',
        data: "{imgName:'" + name.toString() + "', imgUrl:'" + src.toString() + "'}",
        dataType: 'json',
        
        contentType: "application/json; charset=utf-8",
        async: false,

    });
}


function showPreview(event) {
    if (event.target.files.length > 0) {
        // var src=URL.createObjectURL(event.target.files[0]);
        var src = window.URL.createObjectURL(event.target.files[0]);
        var preview = document.getElementById("file-ip-1-preview")
        preview.src = src

        preview.style.display = "block";
        //console.log("url", src)
    }
}
function toggle() {
    document.querySelector(".list").classList.toggle("show");
    document.querySelector(".down-arrow").classList.toggle("rotate180");
}
function updateGenre(obj) {
    if (selectedgenre.includes(data[parseInt(obj.id)])) {
        selectedgenre.splice(selectedgenre.indexOf(data[parseInt(obj.id)]), 1)
    }
    else {
        selectedgenre.push(data[parseInt(obj.id)])
    }
    //console.log(selectedgenre)
}




