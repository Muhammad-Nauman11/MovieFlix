﻿
$(document).ready(function () {
    $.ajax({
        url: 'MovieFlix.aspx/getMovies',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (data) {
            repFunc(data, '#dataTable')
        }
    });
})
function repFunc(data, tablename) {
    //console.log(JSON.parse(data.d)[0]['MovieName'],"done")
    data = JSON.parse(data.d)

        //var markup=`<div style="width:500px; height:350px;">
        //    <div style='float:left'>
        //        <img src="../Posters/${data[0]['Image_Path']}" alt="Assassin" width="300" height="300">
        //    </div>
        //    <div style='float:right'>
        //        <h2 style='text-align: left;'>${data[0]['MovieName']} (${data[0]['Year']})</h2>
        //        <h2 style='text-align: left;'>IMDB: 6.4</h2>
        //        <h2 style='text-align: left;'>Duration: <span style='color:yellow;'>${data[0]['Duration']}</span></h2>
        //        <h2  style='text-align: left;'>Price: <span style='color:green;'>${data[0]['Price']}$</span></h2>
        //    </div>
        //    <div style='text-align: justify;'>${data['Description']}</div>
        //</div>`;
    for (var i = 0; i < data.length; i++)
    {
       var markup= `<div class="card" style="width: 18rem;">
            <img class="card-img-top" src='../Posters/${data[i]['Image_Path']}' width="200px" height="200px" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">${data[i]['MovieName']} (${data[i]['Year']})</h5>
                    <p class="card-text">Duration: ${data[i]['Duration']}</p>
                    <p class="card-text">IMDB: <span style='color:gold;'>${data[i]['Rating']}</span></p>
                    <p class="card-text">Price: <span style='color:green;'>${data[i]['Price']}$</span></p>
                    <button class="btn btn-primary">Add to cart</button>
                </div>
        </div>`;
        $("#datatable").append(markup);
    }

    //$('#dataTable').DataTable({
    //    data: data,
    //    columns: [
    //        {
    //            title: 'id',
    //            data: null,
    //            render: (data, type, row, meta) => meta.row + 1
    //        },


    //        {
    //            data: data,
    //            "render": function (data) {
    //                console.log(data)
    //                var Element = `<img src="../Posters/ACR.jpg" alt="Assassin" width="300" height="300">`;
    //                return Element;
    //            },
    //        },

    //        {
    //            'data': 'Rating',
    //            "render": function (data, type, row, meta) {
    //                var deleteButton = `<button type="button" id="${meta.row}" data-toggle="modal" data-target="#userModal" class="btn action-btn btn-success btn-sm edit-btn mr-1" onclick="deleteData(this)">Delete</button>`;
    //                return deleteButton;
    //            },
    //            "sortable": false,
    //            "searchable": false,
    //            "visible": true
    //        }
    //    ],
    //    order: [[0, 'asc']],
    //});
}
function deleteData(obj) {
    var assent = confirm("Do you really want to delete.")
    if (assent) {
        //deleteOnServerSide($('#dataTable').DataTable().row(parseInt(obj.id)));
        $('#dataTable').DataTable().on('click', 'tbody td ', function () {
            var rowData = parseInt($('#dataTable').DataTable().cell(this).index().row);
            var userId = parseInt($('#dataTable').DataTable().cell(rowData, 0).data())
            console.log(userId, rowData)
            $('#dataTable').DataTable().row(rowData).remove().draw();
            deleteOnServerSide(userId)
        });

    }

}
function deleteOnServerSide(ID) {
    $.ajax({
        url: 'ManageCustomers.aspx/deleteUser',
        method: 'post',
        dataType: 'json',

        contentType: 'application/json',
        data: "{id:'" + ID.toString() + "'}",
        async: false,
        success: function (data) {
            alert("Deleted successfully")
        }
    });
}


//<img src='${data.d[meta.row]["ImagePath"]}'>
