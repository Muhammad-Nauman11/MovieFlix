﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BusinessLayer;

namespace WebApplication1.PresentationLayer
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void callIt(object sender, EventArgs e)
        {
            Response.Write("<script>alert('It comes')</script>");
        }
        [WebMethod]
        public static string Register(string name, string email, string password, string address, string contact, bool IsAdmin)
        {
            User user = new User( name,  email,  password, address, contact, IsAdmin);
            string regMsg = user.Register();
            return regMsg;

        }
    }
}