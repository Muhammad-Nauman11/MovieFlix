﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using WebApplication1.BusinessLayer;

namespace WebApplication1.PresentationLayer
{
    public partial class AddMovie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("PresentationLayer/Login.aspx");
            }
            if (!IsPostBack) { 
            AllGenres genres = new AllGenres();
            for (int i = 0; i < genres.allGenres.Count; i++) 
            {
                Genre genre = genres.allGenres[i];
                ListItem li = new ListItem();
                li.Text = genre.Name;
 
                genreList.Items.Add(li);
            }
            }
        }
  
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            List<string> selectedGenres = new List<string>();

            for (int i = 0; i < genreList.Items.Count; i++)
            {
                if (genreList.Items[i].Selected)
                {
                    selectedGenres.Add(genreList.Items[i].Text);
                }
            }


            if (imgUpload.PostedFile != null && selectedGenres.Count > 0 && namebox.Value!="" && yearbox.Value != "" && ratingbox.Value != "" && durationbox.Value != "" && pricebox.Value != "" && descriptionbox.Value != "")
            {
                string name = namebox.Value;
                int year = Convert.ToInt32(yearbox.Value);
                float rating = (float)Convert.ToSingle(ratingbox.Value);
                string duration = durationbox.Value;
                float price = (float)Convert.ToSingle(pricebox.Value);
                string imagename = Path.GetFileName(imgUpload.PostedFile.FileName);
                //string imagepath = Server.MapPath(@"..\Posters\" + imagename);
                string imagepath = Server.MapPath(@"../Posters/" + imagename);
                //Check whether Directory (Folder) exists.
                if (!Directory.Exists(Server.MapPath(@"../Posters/")))
                {
                    //If Directory (Folder) does not exists Create it.
                    Directory.CreateDirectory(Server.MapPath(@"../Posters/"));
                }
                string description = descriptionbox.Value;
                if (!File.Exists(imagepath))
                {
                    imgUpload.SaveAs(imagepath);
                }

                Movie movie = new Movie(name, year, rating, duration, price, imagename, description);
                string message=movie.AddToDb();
                if (message.Contains("successfully"))
                {
                    foreach (string selectedgenre in selectedGenres)
                    {
                        Genre movieGenre = new Genre();
                        
                        movieGenre.Name = selectedgenre;
                        movieGenre.getGenreID();
                        movieGenre.addGenre(movie.ID);
                    }
                }
                else {
                    Response.Write($"<script>alert('{message}')</script>");
                }
            }
            else 
            {
                Response.Write("<script>alert('Please fill all the fields.')</script>");
            }
        }
        protected void CheckBoxList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (imgUpload.PostedFile != null)
            { 
                poster.ImageUrl =imgUpload.PostedFile.FileName; 
            }
        }

    }
}