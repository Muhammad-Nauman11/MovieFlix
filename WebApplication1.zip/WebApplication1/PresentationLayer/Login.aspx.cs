﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BusinessLayer;

namespace WebApplication1.PresentationLayer
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }
        [WebMethod]
        public static string Loginuser(string name, string email, string password)
        {

            User user = new User(name, email, password);
            string regMsg = user.Login();
            if (regMsg == "success")
                {
                    HttpContext.Current.Session["User"]=user;
                    return $"{regMsg},{user.ID},{user.Name},{user.Address},{user.Contact},{user.IsAdmin}";
                }
            return regMsg;

        }
    }
}