﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication1.BusinessLayer
{
    public class Genre
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public int ID { get; set; }
        public string Name { get; set;}

        public void addGenre(int MovieID) 
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
            con.Open();
            using (con) 
            { 
                SqlCommand com = new SqlCommand("addMovieGenre", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@MovieID", MovieID);
                com.Parameters.AddWithValue("@GenreID", ID);
 

                com.ExecuteNonQuery();
                con.Close();
            }
        }
        public void getGenreID()
        {
            con.Open();
            using (con)
            {
                
                SqlCommand com = new SqlCommand("getGenreByName", con);
                com.Parameters.AddWithValue("@Genrename", Name);
                com.CommandType = CommandType.StoredProcedure;


                SqlDataReader reader = com.ExecuteReader();

                while (reader.Read())
                {
                    ID = (int)reader["ID"];
                }

                reader.Close();

            }
            con.Close();
        }
    }
    public class AllGenres 
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public List<Genre> allGenres=new List<Genre>();
        public AllGenres() 
        {
            DataTable t1 = new DataTable();
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getAllGenres", con);
                com.CommandType = CommandType.StoredProcedure;


                SqlDataReader reader = com.ExecuteReader();

                while (reader.Read())
                {
                    Genre genre = new Genre();
                    genre.ID = (int)reader["ID"];
                    genre.Name = reader["Genrename"].ToString();
                    allGenres.Add(genre);

                }

                reader.Close();
                con.Close();

            }
        }

    }
}