﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;

namespace WebApplication1.BusinessLayer
{
    public class Movie
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public int ID { get; set; }
        string Name { get; set; }
        int Year { get; set; }
        float Rating { get; set; }
        string Duration { get; set; }
        float Price { get; set; }
        string ImgPath { get; set; }
        string Description { get; set; }
        List<Genre> movieGenres = new List<Genre>();
        public string genreStatement { get; set; }

        public Movie()
        {

        }
        public Movie(string name, int year, float rating, string duration, float price, string imgpath, string description)
        {
            Name = name;
            Year = year;
            Rating = rating;
            Duration = duration;
            Price = price;
            ImgPath = imgpath;
            Description = description;
        }
        public string AddToDb()
        {
            SqlCommand com = new SqlCommand("addMovie", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@MovieName", Name);
            com.Parameters.AddWithValue("@Year", Year);
            com.Parameters.AddWithValue("@Rating", Rating);
            com.Parameters.AddWithValue("@Duration", Duration);
            com.Parameters.AddWithValue("@Price", Price);
            com.Parameters.AddWithValue("@Image_Path", ImgPath);
            com.Parameters.AddWithValue("@Description", Description);


            con.Open();

            int progress = com.ExecuteNonQuery();
            con.Close();
            if (progress == -1)
            {
                return "Unable to add move";
            }
            setID();
            getMovieGenres();
            return "Movie is added successfully";
        }
        public void setID()
        {
            SqlCommand com = new SqlCommand($"Select ID from Movies Where MovieName='{Name}'", con);
            con.Open();

            SqlDataReader reader = com.ExecuteReader();

            while (reader.Read())
            {
                ID = (int)reader["ID"];
            }
            con.Close();


        }
        public void getMovieGenres() 
        {

            SqlCommand com = new SqlCommand("getMovieGenres", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@MovieID", ID);
            genreStatement = "";
            con.Open();
            SqlDataReader reader = com.ExecuteReader();

            while (reader.Read())
                
            {
                Genre movieGenre = new Genre();
                movieGenre.ID = (int)reader["Genre_ID"];
                movieGenre.Name = (string)reader["Genrename"];
                genreStatement += $",{movieGenre.Name}";
                movieGenres.Add(movieGenre);
            }
            con.Close();
            if (genreStatement.Contains(',')) 
            {
                genreStatement=genreStatement.Remove(0, 1); 
            }
        }

        public void DeleteFromDB()
        {

        }
    }

    public class Moviestore
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public List<Movie> allMovies= new List<Movie>();
        public Moviestore()
        {
            
        }
        public DataTable getAllMovies()
        {
            DataTable dataTable = new DataTable();
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getAllMovies", con);
                com.CommandType = CommandType.StoredProcedure;

                using (SqlDataAdapter a = new SqlDataAdapter(com))
                {
                    a.Fill(dataTable);
                }
                con.Close();

            }

            dataTable.Columns.Add("Genre");

            foreach (DataRow row in dataTable.Rows)
            {
  
                Movie movie = new Movie(row[1].ToString(), (int)row[2], Convert.ToSingle(row[3]), row[4].ToString(), Convert.ToSingle(row[5]), row[6].ToString(), row[7].ToString());
                movie.setID();
                movie.getMovieGenres();
                allMovies.Add(movie);
                row["Genre"] = movie.genreStatement;

            }


            return dataTable;
        }
    }
    public class SearchEngine
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public List<Movie> allMovies = new List<Movie>();
        
        public User user;
        public SearchEngine()
        {

        }
        public DataTable showSuggestion()
        {
            DataTable dataTable = new DataTable();
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getUserHistoryGenre", con);
                com.Parameters.AddWithValue("@UserID", user.ID);
                com.CommandType = CommandType.StoredProcedure;

                using (SqlDataAdapter a = new SqlDataAdapter(com))
                {
                    a.Fill(dataTable);
                }
                con.Close();

            }
            return dataTable;
        }
    }
}