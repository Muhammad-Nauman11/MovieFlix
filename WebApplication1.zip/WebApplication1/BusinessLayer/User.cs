﻿//                                                  Error
//existance check is not considering capital and small letters differnce


using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication1.BusinessLayer
{
    public class User
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public int ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        private string Password { get; set; }
        public string Address { get; set; }
        public string Contact { get; set; }
        public bool IsAdmin { get; set; }
        public Cart cart = new Cart();
        public User() 
        {
        
        }
        public User(string name, string email, string password)
        {
            Name = name;
            Email = email;
            Password = password;
        }
        public User(string name, string email, string password, string address, string contact, bool isadmin) 
        {
            Name = name;
            Email = email;
            Password = password;
            Address = address;
            Contact = contact;
            IsAdmin = false;

        }

        public string Register() 
        {

            if (checkNameExistance())
            {
                return "nameExist";
            }
            else if (checkEmailExistance())
            {
                return "emailExist";
            }
            else 
            {
                int usertype = IsAdmin ? 1 : 0;
                SqlCommand com = new SqlCommand("AddUser", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Username", Name);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@Password", Password);
                com.Parameters.AddWithValue("@Address", Address);
                com.Parameters.AddWithValue("@Contact", Contact);
                //com.Parameters.AddWithValue("@IsAdmin", usertype);

                con.Open();
                //con.Execute("dbo.AddUser", new { @Name = Name, @Email = Email, @Password = Password, @IsAdmin = usertype, @Address = Address, @Contact = Contact }, commandType: CommandType.StoredProcedure);
                com.ExecuteNonQuery();
                con.Close();
                return "success";
            }

        }
        public bool checkNameExistance()
        {
            SqlCommand com = new SqlCommand("checkNameExistance", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Username", Name);
            var pReturnValue = com.Parameters.Add("@ReturnValue", SqlDbType.Int);
            pReturnValue.Direction = ParameterDirection.ReturnValue;
            con.Open();
         
            com.ExecuteNonQuery();
            con.Close();
            if (Convert.ToInt32(pReturnValue.Value) > 0)
            {
                return true;
            }
            return false;
        }
        public bool checkEmailExistance()
        {

            SqlCommand com = new SqlCommand("checkEmailExistance", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Email", Email);

            var pReturnValue =com.Parameters.Add("@ReturnValue", SqlDbType.Int);
            pReturnValue.Direction = ParameterDirection.ReturnValue;
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            if (Convert.ToInt32(pReturnValue.Value) > 0)
            {
                return true;
            }
            return false;
        
        }

        public string Login() 
        {
            //SqlCommand nameValidation = new SqlCommand($"SELECT * FROM Users WHERE Username='{Name}'", con);
            //SqlCommand emailValidation = new SqlCommand($"SELECT * FROM Users WHERE Email='{Email}'", con);
            bool isNameValid = checkNameExistance();
            bool isEmailValid = checkEmailExistance();

            if (isNameValid && isEmailValid)
            {
                SqlCommand com = new SqlCommand("loginUser", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Name", Name);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@Password", Password);
                var pReturnValue = com.Parameters.Add("@ReturnValue", SqlDbType.Int);
                pReturnValue.Direction = ParameterDirection.ReturnValue;
                con.Open();
                com.ExecuteNonQuery();
                con.Close();
                if (Convert.ToInt32(pReturnValue.Value) > 0)
                {
                    getUserNonCriticalData();
                    return "success";
                }
                return "invalidP";
            }
            else 
            {
                if (!isNameValid) 
                {
                    return "invalidN";
                }

                else
                {
                    return "invalidE";
                }
            }

        }
        public void getUserNonCriticalData() 
        {
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getUserData", con);
                com.Parameters.AddWithValue("@Name", Name);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {

                    ID = Convert.ToInt32(rdr["ID"]);
                    Address = rdr["Address"].ToString();
                    Contact = rdr["Contact"].ToString();
                    IsAdmin = Convert.ToBoolean(rdr["IsAdmin"]);
                }
                con.Close();
            }

        }
        public void delete(int Id) 
        {
            SqlCommand com = new SqlCommand("deleteUser", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ID", Id);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
        }
        public DataTable getAllUsers()
        {
            DataTable t1 = new DataTable();
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getAllUsers", con);
                com.CommandType = CommandType.StoredProcedure;
                //SqlDataReader rdr = com.ExecuteReader();

                using (SqlDataAdapter a = new SqlDataAdapter(com))
                {
                    a.Fill(t1);
                }
                
            }
            return t1;
        }

    }

    public class UserList
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        public  UserList()
        {

        }
        //Return list of all Users  
        public List<User> ListAll()
        {
            List<User> lst = new List<User>();
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getAllUsers", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    User user = new User();
                    user.ID = Convert.ToInt32(rdr["ID"]);
                    user.Name = rdr["Username"].ToString();
                    user.Email=Convert.ToString(rdr["Email"]);
                    user.Address = rdr["Address"].ToString();
                    user.Contact = rdr["Contact"].ToString();
                    lst.Add(user);
                }
                return lst;
            }
        }
        public void deleteUser(User user) 
        {
            user.delete(user.ID);
        }
    }
}