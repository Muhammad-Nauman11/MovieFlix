﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication1.BusinessLayer
{
    public class Cart
    {
       

        List<Movie> movies { get; set; }
        public int UserID { get; set; }
        public float totalbill { get; set; }
        public int ID { get; set; }

        public Cart() 
        {
            
        }
        public void addMovie() 
        {
            Movie movie = new Movie();
            movies.Add(movie);
        }
        public void savePurchases(string movieID, string price) 
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
            con.Open();
            using (con)
            {
                SqlCommand cmd = new SqlCommand("savePurchaseDetails", con);
                cmd.Parameters.AddWithValue("@Purchased_ID", ID);
                cmd.Parameters.AddWithValue("@Movie_ID", Convert.ToInt32(movieID));

                cmd.Parameters.AddWithValue("@Price", (float)Convert.ToSingle(price));
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.ExecuteNonQuery();


            }
            con.Close();
        }
        public void addToCart() {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
            con.Open();
            string format = "yyyy-MM-dd HH:mm:ss";
            string dateTimeVariable = DateTime.Now.ToString(format);
            using (con)
            {
                SqlCommand cmd = new SqlCommand("savePurchase", con);
                cmd.Parameters.AddWithValue("@User_ID", UserID);
                cmd.Parameters.AddWithValue("@IssuedDatetime", dateTimeVariable);
                cmd.Parameters.AddWithValue("@Total_Bill", totalbill);
                cmd.CommandType = CommandType.StoredProcedure;




                int maxID = Convert.ToInt32(cmd.ExecuteScalar());

                ID = maxID;
     

            }
            con.Close();
        }
    }
}